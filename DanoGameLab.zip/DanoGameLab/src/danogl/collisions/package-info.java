/**
 * Collision handling of GameObjects
 * @author Dan Nirel
 */
package danogl.collisions;